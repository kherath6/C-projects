﻿/* Name: Growth Rate Calculator(Assingment 01)
 * Purpose: Calculate and compare the growth rate of Grad and Undergrad students
 * Programmer <Kemil Herath>
 * Date: <09/11/2018>
 * 
 */

 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GrowthRateCalculator
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblCurrentYearGrad_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void btnClearScreen_Click(object sender, EventArgs e)
        {// Clear all entries from the screen

            txtGradCurrent.Text = String.Empty;
            txtGradPrevious.Text = "";
            txtUndergradCurrent.Text = String.Empty;
            txtUndergradPrevious.Text = "";
            lblActualGrowth.Text = String.Empty;
            lblCurrentYearTotal.Text = "";
            lblPreviousYearTotal.Text = String.Empty;
            lblProjectedGrowth.Text = "";


            // Assign the focus to Current Year Grad text box.

            txtGradCurrent.Focus();


        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {// code btnCalculate for computations

            // Declare variables
            double totalCurrent;
            int totalPrevious;
            double actualGrowth;
            double projectGrowth;

            // Declare a constant to hold the Growth rate
            const double GROWTH_RATE = 0.03;


            // Compute results
            totalCurrent = int.Parse(txtGradCurrent.Text) + int.Parse(txtUndergradCurrent.Text);
            totalPrevious = int.Parse(txtGradPrevious.Text) + int.Parse(txtUndergradPrevious.Text);
            actualGrowth = (totalCurrent - totalPrevious) / totalPrevious;
            projectGrowth = (totalCurrent * GROWTH_RATE) + totalCurrent;


            // Display results
            lblCurrentYearTotal.Text = totalCurrent.ToString();
            lblPreviousYearTotal.Text = totalPrevious.ToString();
            lblActualGrowth.Text = actualGrowth.ToString("P");
            lblProjectedGrowth.Text = projectGrowth.ToString();
            

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void txtGradCurrent_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
